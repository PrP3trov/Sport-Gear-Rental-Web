﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportGearRental.Services.ServiceContracts;
using SportGearRental.ViewModels.Rentals;
using System.Security.Claims;

namespace SportGearRental.Web.Controllers
{
    [Authorize]
    public class RentalController : Controller
    {
        private readonly IRentalService _rentalService;

        public RentalController(IRentalService rentalService)
        {
            _rentalService = rentalService;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var rentals = await _rentalService.GetAllAsync(userId);
            return View(rentals);
        }

        public async Task<IActionResult> Details(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var rental = await _rentalService.GetByIdAsync(id, userId);

            if (rental == null)
            {
                return NotFound();
            }

            return View(rental);
        }

        public async Task<IActionResult> Create()
        {
            var model = new RentalFormModel
            {
                SportGears = await _rentalService.GetSportGearsForDropdownAsync()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RentalFormModel model)
        {
            if (!ModelState.IsValid)
            {
                model.SportGears = await _rentalService.GetSportGearsForDropdownAsync();
                return View(model);
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            await _rentalService.CreateAsync(model, userId);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateQuickRental(RentalFormModel model)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Index", "SportGear");
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            await _rentalService.CreateAsync(model, userId);

            return RedirectToAction("Index", "Rental");
        }

        public async Task<IActionResult> Delete(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var rental = await _rentalService.GetByIdAsync(id, userId);

            if (rental == null)
            {
                return NotFound();
            }

            return View(rental);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            await _rentalService.DeleteAsync(id, userId);
            return RedirectToAction(nameof(Index));
        }
    }
}
